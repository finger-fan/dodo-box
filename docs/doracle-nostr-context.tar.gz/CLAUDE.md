# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Doracle (also called Doracle in this fork) is a **Nostr protocol web client** focused on relay selection, web-of-trust moderation, content recommendations, and privacy protection. Built with Svelte 4, TypeScript, and Vite.

## Common Commands

```bash
# Development
pnpm run dev              # Start dev server (http://localhost:5173)
pnpm run watch           # Watch mode for file changes

# Testing
pnpm run test            # Run all tests (unit + e2e)
pnpm run test:unit       # Run unit tests with Vitest
pnpm run test:e2e        # Run E2E tests with Cypress

# Building
pnpm run build           # Production build
pnpm run build:widget    # Build as standalone widget

# Mobile (Capacitor)
pnpm run run:android     # Run on Android device/emulator
pnpm run release:android # Build Android APK

# Code Quality
pnpm run check           # Run TypeScript + ESLint checks
pnpm run check:ts        # TypeScript type checking only
pnpm run check:es        # ESLint linting only
pnpm run format          # Format code with Prettier
```

## Architecture

### Tech Stack
- **Frontend**: Svelte 4 + TypeScript (~5.5)
- **Build**: Vite 5 + Rollup
- **Styling**: Tailwind CSS 3.x with custom HSL color system (shadcn/ui variables)
- **State**: Welshman Store (@welshman/store)
- **Nostr**: @welshman/* (0.8.3), nostr-tools
- **i18n**: svelte-i18n
- **Mobile**: Capacitor (Android/iOS)
- **Testing**: Vitest (unit) + Cypress (e2e)

### Key Directories

| Directory | Purpose |
|-----------|---------|
| `src/app/` | Main app components, routes, views |
| `src/app/views/` | Page views (73 files) |
| `src/app/shared/` | Shared UI components (111 files) |
| `src/domain/` | Domain logic |
| `src/engine/` | Core engine |
| `src/i18n/` | Internationalization |
| `src/partials/` | Reusable partial components (71 files) |
| `src/util/` | Utility functions |
| `src/workers/` | Web workers |
| `tests/unit/` | Unit tests |
| `cypress/e2e/` | E2E tests |

### Design System

- Uses Tailwind CSS with HSL color variables (from shadcn/ui)
- All colors defined in `tailwind.config.cjs`
- Component library follows Telegram-style UI (per recent refactor)

## Important Notes

- PWA is configured but currently disabled in dev mode for Cypress compatibility
- Uses pnpm as package manager
- Environment variables go in `.env` (see `.env.template` for available options)
- White-labeling supported via env vars (`VITE_APP_NAME`, `VITE_APP_URL`, `VITE_DARK_THEME`, etc.)

## Authentication

Doracle uses a **Vault-based authentication system** with two-tier identity management:

### Concepts

**账号** = 用户名 + 密码登录的账户
- 用于解锁保险库（Vault）
- 一个账号可以管理多个身份
- 账号信息加密存储在 Nostr 网络上（通过派生密钥）
- 例如：用户名 "alice"，密码 "password123"

**身份** = Nostr identity (公钥/私钥对)
- 用于在 Nostr 网络上进行签名和加密操作
- 一个账号可以拥有多个身份（例如：工作、个人、测试）
- 身份的私钥被账号密码加密后存储在保险库中
- 例如：npub1xxx, nsec1yyy

### Flow

1. **登录账号** (`/vault/login`): 用户名 + 密码 → 解锁保险库
2. **选择/创建身份** (`/vault/select`): 选择现有身份 或 创建新身份 或 导入已有身份
3. **自动锁定**: 20秒无活动后锁定应用，需要密码重新解锁
4. **切换账号** (`/vault/unlock` 点击"切换账号"): 返回登录页面，用另一个账号登录

### Key Routes

| Route | Purpose |
|-------|---------|
| `/vault/login` | 账号登录/注册 |
| `/vault/select` | 选择/创建/导入身份 |
| `/vault/unlock` | 解锁已锁定的应用 |
| `/` | 主页面（需要已解锁状态）|

### Key Files
- `src/engine/vault/` - Vault session management
- `src/app/views/VaultLoginPage.svelte` - Login/register page
- `src/app/views/VaultAccountSelectPage.svelte` - Identity management (选择/创建/导入身份)
- `src/app/views/VaultUnlockPage.svelte` - Unlock screen

### Translation Keys

| Key | Purpose |
|-----|---------|
| `login.switchIdentity` | 切换身份（在同一账号内切换不同的 Nostr identity）|
| `login.switchVaultAccount` | 切换账号（退出当前账号，返回登录页面）|

## Nostr NIPs Supported

NIP-05, NIP-17 (DMs), NIP-24, NIP-32, NIP-42 (AUTH), NIP-50, NIP-51, NIP-52, NIP-65, NIP-72, NIP-87, NIP-89, NIP-96, NIP-99
