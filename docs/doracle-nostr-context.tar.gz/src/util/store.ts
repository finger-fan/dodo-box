// React hooks for bridging Svelte stores to React
// This allows us to keep using @welshman/store while migrating to React

import { useSyncExternalStore, useCallback, useMemo } from "react"
import type { Readable, Writable, Subscriber, Unsubscriber } from "svelte/store"

/**
 * Subscribe to a Svelte readable store in React
 */
export function useStore<T>(store: Readable<T>): T {
  const subscribe = useCallback(
    (onStoreChange: (value: T) => void) => {
      const unsubscribe = store.subscribe(onStoreChange)
      return () => unsubscribe()
    },
    [store]
  )

  const getSnapshot = useCallback(() => {
    // Get the current value from the store
    let value: T
    const unsubscribe = store.subscribe((v) => {
      value = v
    })
    unsubscribe()
    return value!
  }, [store])

  return useSyncExternalStore(subscribe, getSnapshot, getSnapshot)
}

/**
 * Subscribe to a Svelte writable store and return [value, setValue]
 * Similar to React's useState
 */
export function useWritable<T>(store: Writable<T>): [T, (value: T | ((prev: T) => T)) => void] {
  const value = useStore(store)

  const setValue = useCallback(
    (newValue: T | ((prev: T) => T)) => {
      if (typeof newValue === "function") {
        store.update((prev) => (newValue as (prev: T) => T)(prev))
      } else {
        store.set(newValue)
      }
    },
    [store]
  )

  return [value, setValue]
}

/**
 * Create a derived value from a store with a selector function
 * Similar to Zustand's selector pattern
 */
export function useStoreSelector<T, S>(store: Readable<T>, selector: (value: T) => S): S {
  const derivedStore = useMemo(() => {
    let currentValue: S
    const subscribers = new Set<Subscriber<S>>()

    const originalUnsubscribe = store.subscribe((value) => {
      currentValue = selector(value)
      subscribers.forEach((subscriber) => subscriber(currentValue))
    })

    return {
      subscribe: (subscriber: Subscriber<S>): Unsubscriber => {
        subscribers.add(subscriber)
        // Immediately call with current value
        subscriber(currentValue)

        return () => {
          subscribers.delete(subscriber)
          if (subscribers.size === 0) {
            originalUnsubscribe()
          }
        }
      },
    }
  }, [store, selector])

  return useStore(derivedStore)
}

/**
 * Convert a Svelte store to a React-compatible store object
 * that can be used with useSyncExternalStore
 */
export function toReactStore<T>(store: Readable<T>) {
  return {
    subscribe: (onStoreChange: (value: T) => void) => {
      const unsubscribe = store.subscribe(onStoreChange)
      return () => unsubscribe()
    },
    getSnapshot: () => {
      let value: T
      const unsubscribe = store.subscribe((v) => {
        value = v
      })
      unsubscribe()
      return value!
    },
  }
}
