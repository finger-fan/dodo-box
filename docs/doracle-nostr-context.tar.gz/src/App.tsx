import "@fortawesome/fontawesome-free/css/fontawesome.css"
import "@fortawesome/fontawesome-free/css/solid.css"
import "src/i18n"

import { useEffect, useState, useMemo } from "react"
import { sleep, memoize } from "@welshman/lib"
import * as lib from "@welshman/lib"
import * as util from "@welshman/util"
import * as signer from "@welshman/signer"
import * as net from "@welshman/net"
import * as app from "@welshman/app"
import logger from "src/util/logger"
import * as misc from "src/util/misc"
import * as nostr from "src/util/nostr"
import { ready } from "src/engine"
import { loadUserData } from "src/app/state"
import { appName } from "src/partials/state"
import { useThemeVariables } from "src/partials/state"
import { router, asPerson, asUrlComponent } from "src/app/util/router"
import { usePage, useModals, useRouterProps } from "src/util/router-hooks"
import { useStore } from "src/util/store"
import { VaultLoginPage } from "src/app/views/VaultLoginPage"
import { VaultUnlockPage } from "src/app/views/VaultUnlockPage"
import { VaultIdentitySelectPage } from "src/app/views/VaultIdentitySelectPage"
import HomePage from "src/app/views/HomePage"
import ChatPage from "src/app/views/ChatPage"
import ContactsPage from "src/app/views/ContactsPage"
import SettingsPage from "src/app/views/SettingsPage"
import About from "src/app/views/About"
import { useVaultUnlocked } from "src/engine/vault/hooks"
import { ConfirmDialog } from "src/partials/ConfirmDialog"

const { pubkey, wrapManager, shouldUnwrap, repository } = app

// Register routes
router.register("/", HomePage)
router.register("/chat/:targetPubkey", ChatPage, {
  requireSigner: true,
  serializers: {
    targetPubkey: asPerson,
  },
})
router.register("/contacts", ContactsPage)
router.register("/settings", SettingsPage, {
  requireSigner: true,
})
router.register("/about", About)
router.register("/qrcode/:code", () => <div>QR Code Page</div>, {
  serializers: {
    code: asUrlComponent("code"),
  },
})

// Vault routes
router.register("/vault/login", VaultLoginPage)
router.register("/vault/select", VaultIdentitySelectPage)
router.register("/vault/unlock", VaultUnlockPage)

router.init()

// Globals (for debugging) - nostr module contains all encoding/decoding functions
Object.assign(window, {
  logger,
  router,
  ...signer,
  ...lib,
  ...util,
  ...net,
  ...app,
  ...nostr,
  ...misc,
})

function App() {
  const [isReady, setIsReady] = useState(false)
  const themeVariables = useThemeVariables()

  useEffect(() => {
    // Theme subscription
    const style = document.createElement("style")
    document.head.append(style)

    style.textContent = `:root { ${themeVariables}; background: var(--neutral-800); }`

    return () => {
      style.remove()
    }
  }, [themeVariables])

  useEffect(() => {
    // Scroll position handling
    let scrollY: number | undefined

    const unsubHistory = router.history.subscribe(($history: any[]) => {
      if ($history[0]?.modal) {
        if (document.body.style.position !== "fixed") {
          scrollY = window.scrollY
          document.body.style.top = `-${scrollY}px`
          document.body.style.position = "fixed"
        }
      } else if (document.body.style.position === "fixed") {
        document.body.setAttribute("style", "")
        if (scrollY !== undefined) {
          requestAnimationFrame(() => {
            window.scrollTo(0, scrollY!)
            scrollY = undefined
          })
        }
      }
    })

    // Dev mode globals
    if (import.meta.env.DEV) {
      ;(window as any).__doracle = { wrapManager, shouldUnwrap, repository, pubkey }
      ;(window as any).get = (store: any) => {
        let value: any
        const unsub = store.subscribe((v: any) => (value = v))
        unsub()
        return value
      }
    }

    // Page tracking
    const unsubPage = router.page.subscribe(
      memoize(($page: any) => {
        if ($page) {
          // logUsage($page.path) - will be imported when state is migrated
        }
        window.scrollTo(0, 0)
      })
    )

    const unsubModal = router.modal.subscribe(($modal: any) => {
      if ($modal) {
        // logUsage($modal.path)
      }
    })

    const unsubRouter = router.listen()

    // Protocol handler
    try {
      const handler = navigator.registerProtocolHandler as (
        scheme: string,
        handler: string,
        name: string
      ) => void

      handler?.("web+nostr", `${location.origin}/%s`, appName)
      handler?.("nostr", `${location.origin}/%s`, appName)
    } catch (e) {
      // pass
    }

    // Cleanup
    return () => {
      unsubPage()
      unsubModal()
      unsubRouter()
      unsubHistory()
    }
  }, [])

  useEffect(() => {
    // App data bootstrap and relay meta fetching
    ready.then(async () => {
      await sleep(350)

      // Per-tab identity isolation
      const tabPubkey = sessionStorage.getItem("tab_pubkey")
      if (tabPubkey && tabPubkey !== app.pubkey.get()) {
        const sessions = app.sessions.get()
        const tabSession = sessions[tabPubkey]
        if (tabSession?.method === "nip01" && tabSession?.secret) {
          app.loginWithNip01(tabSession.secret)
          await sleep(100)
        }
      }

      const currentSession = app.session.get()
      if (currentSession) {
        loadUserData()
      }

      setIsReady(true)
    })
  }, [])

  if (!isReady) {
    return null
  }

  return (
    <div className="text-tinted-200">
      <Routes />
    </div>
  )
}

// Routes that don't require vault authentication
const PUBLIC_ROUTES = ["/vault/login", "/vault/unlock", "/about"]

// Routes that require vault unlocked but don't require a selected identity
const VAULT_ROUTES = ["/vault/select"]

// Routes component - renders the current page and modals
function Routes() {
  const page = usePage()
  const modals = useModals()
  const pageProps = useRouterProps(page)
  const isVaultUnlocked = useVaultUnlocked()
  const currentPubkey = useStore(app.pubkey)

  // Route guard logic
  const guardedPageContent = useMemo(() => {
    if (!page) return null

    const currentPath = page.path.split("?")[0] // Remove query params

    // Check if it's a public route
    const isPublicRoute = PUBLIC_ROUTES.some(route => currentPath.startsWith(route))
    const isVaultRoute = VAULT_ROUTES.some(route => currentPath.startsWith(route))

    // If vault is not unlocked and trying to access protected route
    if (!isVaultUnlocked && !isPublicRoute) {
      // Redirect to vault login
      setTimeout(() => router.at("/vault/login").replace(), 0)
      return null
    }

    // If vault is unlocked but no identity selected and trying to access protected route
    if (isVaultUnlocked && !currentPubkey && !isPublicRoute && !isVaultRoute) {
      // Redirect to identity select
      setTimeout(() => router.at("/vault/select").replace(), 0)
      return null
    }

    try {
      const match = router.getMatch(page.path)
      const Component = match.route.component
      return <Component {...pageProps} />
    } catch (e) {
      logger.error("Failed to render page:", e)
      return <div>Page not found</div>
    }
  }, [page, pageProps, isVaultUnlocked, currentPubkey])

  return (
    <>
      {guardedPageContent}
      {modals.map(modal => (
        <ModalItem key={modal.key || modal.path} modal={modal} />
      ))}
      <ConfirmDialog />
    </>
  )
}

// Separate component for each modal to properly use hooks
function ModalItem({ modal }: { modal: any }) {
  const modalProps = useRouterProps(modal)

  try {
    const match = router.getMatch(modal.path)
    const Component = match.route.component
    return (
      <div className="modal-overlay">
        <Component {...modalProps} />
      </div>
    )
  } catch (e) {
    logger.error("Failed to render modal:", e)
    return null
  }
}

export default App
