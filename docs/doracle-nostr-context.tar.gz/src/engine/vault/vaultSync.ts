// vaultSync.ts - 保险库同步模块
// Sync vault data with Nostr relays

import {publishThunk} from "@welshman/app"
import {makeEvent, type TrustedEvent} from "@welshman/util"
import {Nip01Signer} from "@welshman/signer"
import {now} from "@welshman/lib"
import {env, myLoad} from "src/engine/state"
import {VAULT_EVENT_KIND, VAULT_EVENT_D_TAG} from "./types"
import type {VaultData} from "./types"
import {encryptVault, decryptVault, createEmptyVaultData} from "./vaultCrypto"

/**
 * 查询保险库事件
 */
async function fetchVaultEvent(masterPublicKey: string): Promise<TrustedEvent | null> {
  const filters = [
    {
      kinds: [VAULT_EVENT_KIND],
      authors: [masterPublicKey],
      "#d": [VAULT_EVENT_D_TAG],
      limit: 1,
    },
  ]

  // 从默认中继器查询
  const events = await myLoad({
    skipCache: true,
    relays: env.DEFAULT_RELAYS,
    filters,
  })

  // 返回最新的事件
  if (events && events.length > 0) {
    return events.sort((a, b) => b.created_at - a.created_at)[0]
  }

  return null
}

/**
 * 发布保险库事件
 */
async function publishVaultEvent(
  masterPrivateKey: string,
  encryptedContent: string
): Promise<void> {
  // 创建签名器
  const signer = Nip01Signer.fromSecret(masterPrivateKey)

  // 创建事件
  const template = makeEvent(VAULT_EVENT_KIND, {
    content: encryptedContent,
    tags: [["d", VAULT_EVENT_D_TAG]],
    created_at: now(),
  })

  // 签名并发布
  const signedEvent = await signer.sign(template)

  // 发布事件（乐观处理，不等待确认）
  publishThunk({
    event: signedEvent,
    relays: env.DEFAULT_RELAYS,
  })
}

export class VaultSync {
  private relays: string[]

  constructor() {
    this.relays = env.DEFAULT_RELAYS
  }

  /**
   * 检查保险库是否存在（查询中继器）
   */
  async checkVaultExists(masterPublicKey: string): Promise<boolean> {
    console.log("[VaultSync] checkVaultExists for pubkey:", masterPublicKey.slice(0, 12) + "...")
    try {
      const event = await fetchVaultEvent(masterPublicKey)
      console.log("[VaultSync] checkVaultExists result:", !!event)
      return event !== null
    } catch (error) {
      console.error("[VaultSync] checkVaultExists failed:", error)
      // 网络错误时假设不存在，让用户有机会注册
      return false
    }
  }

  /**
   * 发布保险库到中继器
   */
  async publishVault(
    masterPrivateKey: string,
    vaultData: VaultData
  ): Promise<void> {
    console.log("[VaultSync] publishVault called")
    try {
      const encryptedContent = await encryptVault(masterPrivateKey, vaultData)
      await publishVaultEvent(masterPrivateKey, encryptedContent)
      console.log("[VaultSync] publishVault completed")
    } catch (error) {
      console.error("[VaultSync] publishVault failed:", error)
      throw error
    }
  }

  /**
   * 从中继器获取保险库
   */
  async fetchVault(
    masterPublicKey: string,
    masterPrivateKey: string
  ): Promise<VaultData | null> {
    console.log("[VaultSync] fetchVault called")
    try {
      const event = await fetchVaultEvent(masterPublicKey)

      if (!event) {
        console.log("[VaultSync] No vault event found")
        return null
      }

      console.log("[VaultSync] Found vault event, decrypting...")
      const vaultData = await decryptVault(masterPrivateKey, event.content)
      console.log("[VaultSync] Vault decrypted, identities:", vaultData.identities.length)
      return vaultData
    } catch (error) {
      console.error("[VaultSync] fetchVault failed:", error)
      throw error
    }
  }

  /**
   * 创建新的保险库（注册新账户）
   */
  async createVault(masterPrivateKey: string): Promise<VaultData> {
    console.log("[VaultSync] createVault called")
    const vaultData = createEmptyVaultData()
    await this.publishVault(masterPrivateKey, vaultData)
    return vaultData
  }

  /**
   * 更新保险库（添加/删除账户后同步）
   */
  async updateVault(
    masterPrivateKey: string,
    vaultData: VaultData
  ): Promise<void> {
    console.log("[VaultSync] updateVault called")
    vaultData.updatedAt = Date.now()
    await this.publishVault(masterPrivateKey, vaultData)
  }
}

// 单例实例
export const vaultSync = new VaultSync()
