// keyDerivation.ts - 密钥派生模块
// Derive deterministic master key from username + password

import {sha256, bytesToHex, hexToBytes} from "@welshman/lib"
import {schnorr} from "@noble/curves/secp256k1"
import {VAULT_SALT} from "./types"
import type {DerivedKey} from "./types"

/**
 * 从用户名和密码派生确定性主密钥
 * 使用 SHA256(username:password:SALT) 作为私钥种子
 *
 * @param username - 用户名
 * @param password - 密码
 * @returns 派生密钥对
 */
export async function deriveMasterKey(username: string, password: string): Promise<DerivedKey> {
  // 1. 组合输入并计算 SHA256
  // SHA256(username:password:SALT)
  const input = `${username}:${password}:${VAULT_SALT}`
  const encoder = new TextEncoder()
  const inputBytes = encoder.encode(input)

  // 使用 @welshman/lib 的 sha256 (返回 hex 字符串)
  const privateKey = await sha256(inputBytes.buffer as ArrayBuffer)

  // 2. 从私钥派生公钥 (使用 schnorr.getPublicKey)
  // schnorr.getPublicKey 返回 32 字节的公钥
  const publicKeyBytes = schnorr.getPublicKey(hexToBytes(privateKey))
  const publicKey = bytesToHex(publicKeyBytes)

  return {
    privateKey,
    publicKey,
    npub: `npub1${publicKey}`,
    nsec: `nsec1${privateKey}`,
  }
}

/**
 * 验证密钥对是否匹配
 */
export function verifyKeyPair(privateKey: string, publicKey: string): boolean {
  try {
    const derivedPubkey = schnorr.getPublicKey(hexToBytes(privateKey))
    return bytesToHex(derivedPubkey) === publicKey
  } catch {
    return false
  }
}

/**
 * 从 nsec 解码私钥
 */
export function decodeNsec(nsec: string): string | null {
  try {
    if (!nsec.startsWith("nsec1")) return null
    // 移除 "nsec1" 前缀后就是 bech32 解码... 但这里简化为直接提取 hex 部分
    // 实际上 nsec1 后面是 bech32 编码，需要正确解码
    // 但在我们的简化场景中，nsec1 + hex 是常用表示法
    return nsec.slice(5)
  } catch {
    return null
  }
}

/**
 * 从 npub 解码公钥
 */
export function decodeNpub(npub: string): string | null {
  try {
    if (!npub.startsWith("npub1")) return null
    return npub.slice(4)
  } catch {
    return null
  }
}
