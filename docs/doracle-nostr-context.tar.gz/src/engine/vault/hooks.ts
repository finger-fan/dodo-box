// React hooks for vault session state
import { useStore } from "src/util/store"
import { vaultSession } from "./sessionManager"
import type { VaultIdentity } from "./types"

/**
 * Hook to check if vault is unlocked
 */
export function useVaultUnlocked(): boolean {
  return useStore(vaultSession.isUnlocked)
}

/**
 * Hook to get vault identities (accounts)
 */
export function useVaultIdentities(): VaultIdentity[] {
  return useStore(vaultSession.identities)
}

/**
 * Hook to get vault accounts (alias for identities)
 */
export function useVaultAccounts(): VaultIdentity[] {
  return useStore(vaultSession.accounts)
}

/**
 * Hook to get current vault username
 */
export function useVaultUsername(): string | null {
  return useStore(vaultSession.username)
}

/**
 * Hook to get vault master key
 */
export function useVaultMasterKey() {
  return useStore(vaultSession.masterKey)
}
