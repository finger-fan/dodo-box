// sessionManager.ts - 会话管理模块
// Manage vault session state, auto-lock, and vault operations

import {writable, derived, get, type Writable} from "svelte/store"
import {loginWithNip01} from "@welshman/app"
import {schnorr} from "@noble/curves/secp256k1"
import {hexToBytes, bytesToHex} from "@welshman/lib"
import type {
  VaultData,
  VaultIdentity,
  DerivedKey,
  VaultAuthResult,
  VaultRegisterResult,
  VaultOperationResult,
} from "./types"
import {deriveMasterKey} from "./keyDerivation"
import {encryptSecret, decryptSecret, createEmptyVaultData} from "./vaultCrypto"
import {vaultSync} from "./vaultSync"

// Store types
type VaultUnlockedStore = Writable<boolean>
type VaultIdentitiesStore = Writable<VaultIdentity[]>
type VaultMasterKeyStore = Writable<DerivedKey | null>
type VaultUsernameStore = Writable<string | null>

/**
 * 会话管理器类
 * 处理保险库的解锁、锁定、身份管理等操作
 */
export class VaultSessionManager {
  // 会话状态存储
  private unlockedStore: VaultUnlockedStore = writable(false)
  private identitiesStore: VaultIdentitiesStore = writable<VaultIdentity[]>([])
  private masterKeyStore: VaultMasterKeyStore = writable<DerivedKey | null>(null)
  private usernameStore: VaultUsernameStore = writable<string | null>(null)

  // 自动锁定相关
  private lastActivity: number = Date.now()
  private lockTimeout: number = 20000 // 20秒
  private lockTimer: ReturnType<typeof setInterval> | null = null
  private activityListeners: Array<() => void> = []

  // 派生存储
  public readonly isUnlocked = derived(this.unlockedStore, $u => $u)
  public readonly identities = derived(this.identitiesStore, $i => $i)
  public readonly masterKey = derived(this.masterKeyStore, $k => $k)
  public readonly username = derived(this.usernameStore, $u => $u)

  // 兼容旧代码（后续移除）
  public readonly accounts = this.identities

  /**
   * 解锁保险库（登录）
   */
  async unlock(username: string, password: string): Promise<VaultAuthResult> {
    console.log("[VaultSessionManager] unlock called for username:", username)
    try {
      // 1. 派生主密钥
      const derivedKey = await deriveMasterKey(username, password)
      console.log("[VaultSessionManager] Master key derived")

      // 2. 从中继器获取保险库
      const vaultData = await vaultSync.fetchVault(
        derivedKey.publicKey,
        derivedKey.privateKey
      )

      if (!vaultData) {
        console.log("[VaultSessionManager] Vault not found")
        return {
          success: false,
          error: "账户不存在，请检查用户名或注册新账户",
        }
      }

      // 3. 设置会话状态
      this.masterKeyStore.set(derivedKey)
      this.identitiesStore.set(vaultData.identities)
      this.usernameStore.set(username)
      this.unlockedStore.set(true)
      this.lastActivity = Date.now()

      // Store username in sessionStorage for guard
      sessionStorage.setItem("vault_username", username)

      // 4. 启动自动锁定监听
      this.startAutoLock()

      console.log("[VaultSessionManager] Unlock successful, accounts:", vaultData.identities.length)
      return {
        success: true,
        data: {
          accounts: vaultData.identities,
          masterPublicKey: derivedKey.publicKey,
        },
      }
    } catch (error) {
      console.error("[VaultSessionManager] unlock failed:", error)
      return {
        success: false,
        error: error instanceof Error ? error.message : "登录失败",
      }
    }
  }

  /**
   * 注册新账户
   */
  async register(username: string, password: string): Promise<VaultRegisterResult> {
    console.log("[VaultSessionManager] register called for username:", username)
    try {
      // 1. 派生主密钥
      const derivedKey = await deriveMasterKey(username, password)
      console.log("[VaultSessionManager] Master key derived")

      // 2. 检查保险库是否已存在
      const exists = await vaultSync.checkVaultExists(derivedKey.publicKey)
      if (exists) {
        console.log("[VaultSessionManager] Vault already exists")
        return {
          success: false,
          error: "该用户名已被注册",
        }
      }

      // 3. 创建空保险库
      const vaultData = createEmptyVaultData()
      await vaultSync.publishVault(derivedKey.privateKey, vaultData)
      console.log("[VaultSessionManager] Empty vault created and published")

      // 4. 设置会话状态
      this.masterKeyStore.set(derivedKey)
      this.identitiesStore.set([])
      this.usernameStore.set(username)
      this.unlockedStore.set(true)
      this.lastActivity = Date.now()

      // 5. 启动自动锁定监听
      this.startAutoLock()

      return {
        success: true,
        data: {
          masterPublicKey: derivedKey.publicKey,
        },
      }
    } catch (error) {
      console.error("[VaultSessionManager] register failed:", error)
      return {
        success: false,
        error: error instanceof Error ? error.message : "注册失败",
      }
    }
  }

  /**
   * 锁定保险库
   */
  lock(): void {
    console.log("[VaultSessionManager] lock called")
    this.unlockedStore.set(false)
    this.masterKeyStore.set(null)
    // 保留账户列表和用户名，以便解锁后恢复
    this.stopAutoLock()
  }

  /**
   * 重新解锁（已登录状态下的解锁）
   */
  async reUnlock(password: string): Promise<VaultAuthResult> {
    const username = get(this.usernameStore)
    if (!username) {
      return {
        success: false,
        error: "会话已过期，请重新登录",
      }
    }

    return this.unlock(username, password)
  }

  /**
   * 检查是否已解锁
   */
  isUnlockedNow(): boolean {
    return get(this.unlockedStore)
  }

  /**
   * 获取主密钥
   */
  getMasterKey(): DerivedKey | null {
    return get(this.masterKeyStore)
  }

  /**
   * 获取身份列表
   */
  getIdentities(): VaultIdentity[] {
    return get(this.identitiesStore)
  }

  // 兼容旧代码
  getAccounts = this.getIdentities

  /**
   * 获取当前用户名
   */
  getUsername(): string | null {
    return get(this.usernameStore)
  }

  /**
   * 添加新身份
   */
  async addIdentity(name: string, privateKey: string): Promise<VaultOperationResult<VaultIdentity>> {
    console.log("[VaultSessionManager] addIdentity called:", name)
    const masterKey = this.getMasterKey()
    if (!masterKey) {
      return {
        success: false,
        error: "保险库已锁定",
      }
    }

    try {
      // 验证私钥并获取公钥
      const pubkeyBytes = schnorr.getPublicKey(hexToBytes(privateKey))
      const pubkey = bytesToHex(pubkeyBytes)

      // 检查是否已存在
      const identities = this.getIdentities()
      if (identities.some(i => i.pubkey === pubkey)) {
        return {
          success: false,
          error: "该账户已存在",
        }
      }

      // 加密私钥
      const encryptedSecret = await encryptSecret(masterKey.privateKey, privateKey)

      // 创建新身份
      const newIdentity: VaultIdentity = {
        name,
        pubkey,
        encryptedSecret,
        createdAt: Date.now(),
      }

      // 更新本地状态
      const newIdentities = [...identities, newIdentity]
      this.identitiesStore.set(newIdentities)

      // 同步到中继器
      const vaultData: VaultData = {
        version: 1,
        identities: newIdentities,
        updatedAt: Date.now(),
      }
      await vaultSync.updateVault(masterKey.privateKey, vaultData)

      console.log("[VaultSessionManager] addAccount completed")
      return {
        success: true,
        data: newIdentity,
      }
    } catch (error) {
      console.error("[VaultSessionManager] addIdentity failed:", error)
      return {
        success: false,
        error: error instanceof Error ? error.message : "添加身份失败",
      }
    }
  }

  // 兼容旧代码
  addAccount = this.addIdentity

  /**
   * 创建新身份（生成新私钥）
   */
  async createIdentity(name: string): Promise<VaultOperationResult<VaultIdentity>> {
    console.log("[VaultSessionManager] createIdentity called:", name)

    // 生成随机私钥
    const randomBytes = new Uint8Array(32)
    crypto.getRandomValues(randomBytes)
    const privateKey = bytesToHex(randomBytes)

    return this.addIdentity(name, privateKey)
  }

  // 兼容旧代码
  createAccount = this.createIdentity

  /**
   * 重命名身份
   */
  async renameIdentity(targetPubkey: string, newName: string): Promise<VaultOperationResult> {
    console.log("[VaultSessionManager] renameIdentity called:", targetPubkey.slice(0, 12), "to:", newName)
    const masterKey = this.getMasterKey()
    if (!masterKey) {
      return {
        success: false,
        error: "保险库已锁定",
      }
    }

    try {
      const identities = this.getIdentities()
      const identity = identities.find(i => i.pubkey === targetPubkey)

      if (!identity) {
        return {
          success: false,
          error: "身份不存在",
        }
      }

      // 更新身份名称
      const updatedIdentity: VaultIdentity = {
        ...identity,
        name: newName,
      }

      const updatedIdentities = identities.map(i =>
        i.pubkey === targetPubkey ? updatedIdentity : i
      )

      // 更新本地状态
      this.identitiesStore.set(updatedIdentities)

      // 同步到中继器
      const vaultData: VaultData = {
        version: 1,
        identities: updatedIdentities,
        updatedAt: Date.now(),
      }
      await vaultSync.updateVault(masterKey.privateKey, vaultData)

      console.log("[VaultSessionManager] renameIdentity completed")
      return {success: true}
    } catch (error) {
      console.error("[VaultSessionManager] renameIdentity failed:", error)
      return {
        success: false,
        error: error instanceof Error ? error.message : "重命名失败",
      }
    }
  }

  // 兼容旧代码
  renameAccount = this.renameIdentity

  /**
   * 删除身份
   */
  async removeIdentity(targetPubkey: string): Promise<VaultOperationResult> {
    console.log("[VaultSessionManager] removeIdentity called:", targetPubkey.slice(0, 12))
    const masterKey = this.getMasterKey()
    if (!masterKey) {
      return {
        success: false,
        error: "保险库已锁定",
      }
    }

    try {
      const identities = this.getIdentities()
      const updatedIdentities = identities.filter(i => i.pubkey !== targetPubkey)

      if (updatedIdentities.length === identities.length) {
        return {
          success: false,
          error: "身份不存在",
        }
      }

      // 更新本地状态
      this.identitiesStore.set(updatedIdentities)

      // 同步到中继器
      const vaultData: VaultData = {
        version: 1,
        identities: updatedIdentities,
        updatedAt: Date.now(),
      }
      await vaultSync.updateVault(masterKey.privateKey, vaultData)

      console.log("[VaultSessionManager] removeIdentity completed")
      return {success: true}
    } catch (error) {
      console.error("[VaultSessionManager] removeIdentity failed:", error)
      return {
        success: false,
        error: error instanceof Error ? error.message : "删除失败",
      }
    }
  }

  // 兼容旧代码
  removeAccount = this.removeIdentity

  /**
   * 切换到指定身份（无需密码）
   */
  async switchToIdentity(targetPubkey: string): Promise<VaultOperationResult<string>> {
    console.log("[VaultSessionManager] switchToIdentity called:", targetPubkey.slice(0, 12))
    const masterKey = this.getMasterKey()
    if (!masterKey) {
      return {
        success: false,
        error: "保险库已锁定",
      }
    }

    try {
      const identity = this.getIdentities().find(i => i.pubkey === targetPubkey)
      if (!identity) {
        return {
          success: false,
          error: "身份不存在",
        }
      }

      // 解密私钥
      const privateKey = await decryptSecret(masterKey.privateKey, identity.encryptedSecret)

      // 使用 @welshman/app 的登录功能
      loginWithNip01(privateKey)

      // 刷新活动时间
      this.refreshActivity()

      console.log("[VaultSessionManager] switchToIdentity completed")
      return {
        success: true,
        data: targetPubkey,
      }
    } catch (error) {
      console.error("[VaultSessionManager] switchToIdentity failed:", error)
      return {
        success: false,
        error: error instanceof Error ? error.message : "切换身份失败",
      }
    }
  }

  // 兼容旧代码
  switchToAccount = this.switchToIdentity

  /**
   * 解密指定身份的私钥
   */
  async decryptIdentitySecret(targetPubkey: string): Promise<string | null> {
    const masterKey = this.getMasterKey()
    if (!masterKey) return null

    const identity = this.getIdentities().find(i => i.pubkey === targetPubkey)
    if (!identity) return null

    return decryptSecret(masterKey.privateKey, identity.encryptedSecret)
  }

  // 兼容旧代码
  decryptAccountSecret = this.decryptIdentitySecret

  /**
   * 刷新活动时间
   */
  refreshActivity(): void {
    this.lastActivity = Date.now()
  }

  /**
   * 启动自动锁定监听
   */
  startAutoLock(): void {
    // 在开发环境下禁用自动锁定，便于 E2E 测试
    if (import.meta.env.DEV) {
      console.log("[VaultSessionManager] Auto-lock disabled in DEV mode")
      return
    }
    if (this.lockTimer) return

    // 监听用户活动
    const activityHandler = () => this.refreshActivity()
    const events = ["mousedown", "keydown", "touchstart", "scroll"]

    events.forEach(event => {
      document.addEventListener(event, activityHandler, {passive: true})
    })

    this.activityListeners = events.map(event => () =>
      document.removeEventListener(event, activityHandler)
    )

    // 定时检查
    this.lockTimer = setInterval(() => {
      if (!this.isUnlockedNow()) return

      const elapsed = Date.now() - this.lastActivity
      if (elapsed >= this.lockTimeout) {
        console.log("[VaultSessionManager] Auto-lock triggered")
        this.lock()
      }
    }, 5000) // 每5秒检查一次
  }

  /**
   * 停止自动锁定监听
   */
  stopAutoLock(): void {
    if (this.lockTimer) {
      clearInterval(this.lockTimer)
      this.lockTimer = null
    }

    this.activityListeners.forEach(cleanup => cleanup())
    this.activityListeners = []
  }

  /**
   * 设置锁定超时时间
   */
  setLockTimeout(timeout: number): void {
    this.lockTimeout = timeout
  }

  /**
   * 完全登出（清除所有状态）
   */
  logout(): void {
    console.log("[VaultSessionManager] logout called")
    this.lock()
    this.identitiesStore.set([])
    this.usernameStore.set(null)
    this.stopAutoLock()
    // Clear sessionStorage
    sessionStorage.removeItem("vault_username")
  }
}

// 全局单例实例
export const vaultSession = new VaultSessionManager()
