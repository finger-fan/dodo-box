// types.ts - 无痕账户相关类型定义
// Vault (Incognito Account) type definitions

/**
 * Vault salt for key derivation
 * Fixed value ensures deterministic key generation from same username+password
 */
export const VAULT_SALT = "doracle-vault-v1"

/**
 * Nostr event kind for vault data storage
 * Using 31990 as application-specific data kind
 */
export const VAULT_EVENT_KIND = 31990

/**
 * Vault event identifier tag
 */
export const VAULT_EVENT_D_TAG = "doracle-vault"

/**
 * A single identity stored in the vault
 */
export interface VaultIdentity {
  /** Display name for this identity */
  name: string
  /** Public key (hex) */
  pubkey: string
  /** AES-GCM encrypted private key (hex string, format: iv:ciphertext) */
  encryptedSecret: string
  /** Creation timestamp (ms) */
  createdAt: number
  /** Optional relay URLs for this identity */
  relayUrls?: string[]
}

/**
 * Complete vault data structure
 * This is encrypted and stored on Nostr relays
 */
export interface VaultData {
  /** Data format version */
  version: 1
  /** List of identities in this vault */
  identities: VaultIdentity[]
  /** Last update timestamp (ms) */
  updatedAt: number
}

/**
 * Derived key from username + password
 */
export interface DerivedKey {
  /** 32-byte private key (hex) */
  privateKey: string
  /** 32-byte public key (hex) */
  publicKey: string
  /** bech32 encoded public key */
  npub: string
  /** bech32 encoded private key */
  nsec: string
}

/**
 * Encrypted vault content structure
 */
export interface EncryptedVaultContent {
  /** Encrypted data (hex) */
  ciphertext: string
  /** Initialization vector (hex) */
  iv: string
}

/**
 * Vault session state
 */
export interface VaultSessionState {
  /** Whether vault is unlocked */
  isUnlocked: boolean
  /** Master public key (available when unlocked) */
  masterPublicKey: string | null
  /** Account list (available when unlocked) */
  accounts: VaultIdentity[]
  /** Username of current session */
  username: string | null
  /** Last activity timestamp */
  lastActivity: number
}

/**
 * Generic vault operation result type
 */
export type VaultOperationResult<T = void> =
  | { success: true; data?: T }
  | { success: false; error: string }

/**
 * Vault authentication result
 */
export type VaultAuthResult = VaultOperationResult<{
  accounts: VaultIdentity[]
  masterPublicKey: string
  /** Whether a previously used identity was automatically restored */
  identityRestored?: boolean
}>

/**
 * Vault registration result
 */
export type VaultRegisterResult = VaultOperationResult<{
  masterPublicKey: string
}>

/**
 * Vault error codes
 */
export const VAULT_ERROR_CODES = {
  INVALID_CREDENTIALS: "INVALID_CREDENTIALS",
  ACCOUNT_NOT_FOUND: "ACCOUNT_NOT_FOUND",
  ACCOUNT_EXISTS: "ACCOUNT_EXISTS",
  VAULT_NOT_FOUND: "VAULT_NOT_FOUND",
  VAULT_EXISTS: "VAULT_EXISTS",
  ENCRYPTION_FAILED: "ENCRYPTION_FAILED",
  DECRYPTION_FAILED: "DECRYPTION_FAILED",
  SYNC_FAILED: "SYNC_FAILED",
  SESSION_LOCKED: "SESSION_LOCKED",
  NETWORK_ERROR: "NETWORK_ERROR",
  INVALID_KEY: "INVALID_KEY",
  REGISTRATION_FAILED: "REGISTRATION_FAILED",
  LOGIN_FAILED: "LOGIN_FAILED",
  UNAUTHORIZED: "UNAUTHORIZED",
} as const

export type VaultErrorCode = (typeof VAULT_ERROR_CODES)[keyof typeof VAULT_ERROR_CODES]

/**
 * Errors thrown by vault operations
 */
export class VaultError extends Error {
  constructor(
    message: string,
    public code: VaultErrorCode
  ) {
    super(message)
    this.name = "VaultError"
  }
}
