// vaultCrypto.ts - 保险库加解密模块
// AES-GCM encryption for vault data and secrets

import {hexToBytes, bytesToHex} from "@welshman/lib"
import {VAULT_ERROR_CODES, VaultError} from "./types"
import type {VaultData, VaultIdentity} from "./types"

const IV_LENGTH = 12

/**
 * 从主私钥派生 AES-GCM 加密密钥
 * 使用 PBKDF2 从主私钥派生对称加密密钥
 */
async function deriveAesKey(masterPrivateKey: string): Promise<CryptoKey> {
  const keyBytes = hexToBytes(masterPrivateKey)

  // 将私钥作为密钥材料
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    keyBytes,
    "PBKDF2",
    false,
    ["deriveKey"]
  )

  // 派生 AES-GCM 密钥（使用固定盐值，因为主密钥本身已经是高熵的）
  const salt = new TextEncoder().encode("vault-aes-key-derivation")
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: salt,
      iterations: 100000,
      hash: "SHA-256",
    },
    keyMaterial,
    {name: "AES-GCM", length: 256},
    false,
    ["encrypt", "decrypt"]
  )
}

/**
 * 生成随机 IV
 */
function generateIV(): Uint8Array {
  return crypto.getRandomValues(new Uint8Array(IV_LENGTH))
}

/**
 * 加密保险库数据
 * @param masterPrivateKey - 主私钥 (hex)
 * @param vaultData - 要加密的保险库数据
 * @returns 加密后的内容 (iv:ciphertext hex 格式)
 */
export async function encryptVault(
  masterPrivateKey: string,
  vaultData: VaultData
): Promise<string> {
  try {
    const aesKey = await deriveAesKey(masterPrivateKey)
    const iv = generateIV()
    const plaintext = JSON.stringify(vaultData)
    const dataBuffer = new TextEncoder().encode(plaintext)

    const ciphertext = await crypto.subtle.encrypt(
      {name: "AES-GCM", iv},
      aesKey,
      dataBuffer
    )

    // 返回格式: iv:ciphertext (都是 hex)
    return `${bytesToHex(iv)}:${bytesToHex(new Uint8Array(ciphertext))}`
  } catch (error) {
    console.error("[VaultCrypto] encryptVault failed:", error)
    throw new VaultError(
      "Failed to encrypt vault",
      VAULT_ERROR_CODES.ENCRYPTION_FAILED
    )
  }
}

/**
 * 解密保险库数据
 * @param masterPrivateKey - 主私钥 (hex)
 * @param encryptedContent - 加密的内容 (iv:ciphertext hex 格式)
 * @returns 解密后的保险库数据
 */
export async function decryptVault(
  masterPrivateKey: string,
  encryptedContent: string
): Promise<VaultData> {
  try {
    const [ivHex, ciphertextHex] = encryptedContent.split(":")
    if (!ivHex || !ciphertextHex) {
      throw new Error("Invalid encrypted content format")
    }

    const aesKey = await deriveAesKey(masterPrivateKey)
    const iv = hexToBytes(ivHex)
    const ciphertext = hexToBytes(ciphertextHex)

    const decrypted = await crypto.subtle.decrypt(
      {name: "AES-GCM", iv},
      aesKey,
      ciphertext
    )

    const plaintext = new TextDecoder().decode(decrypted)
    const data = JSON.parse(plaintext)

    // 验证数据结构
    if (data.version !== 1 || !Array.isArray(data.identities)) {
      throw new Error("Invalid vault data structure")
    }

    return data as VaultData
  } catch (error) {
    console.error("[VaultCrypto] decryptVault failed:", error)
    throw new VaultError(
      "Failed to decrypt vault",
      VAULT_ERROR_CODES.DECRYPTION_FAILED
    )
  }
}

/**
 * 加密子账户私钥
 * @param masterPrivateKey - 主私钥 (hex)
 * @param secret - 子账户私钥 (hex)
 * @returns 加密后的私钥 (iv:ciphertext hex 格式)
 */
export async function encryptSecret(
  masterPrivateKey: string,
  secret: string
): Promise<string> {
  try {
    const aesKey = await deriveAesKey(masterPrivateKey)
    const iv = generateIV()
    const dataBuffer = new TextEncoder().encode(secret)

    const ciphertext = await crypto.subtle.encrypt(
      {name: "AES-GCM", iv},
      aesKey,
      dataBuffer
    )

    return `${bytesToHex(iv)}:${bytesToHex(new Uint8Array(ciphertext))}`
  } catch (error) {
    console.error("[VaultCrypto] encryptSecret failed:", error)
    throw new VaultError(
      "Failed to encrypt secret",
      VAULT_ERROR_CODES.ENCRYPTION_FAILED
    )
  }
}

/**
 * 解密子账户私钥
 * @param masterPrivateKey - 主私钥 (hex)
 * @param encryptedSecret - 加密的私钥 (iv:ciphertext hex 格式)
 * @returns 解密后的私钥 (hex)
 */
export async function decryptSecret(
  masterPrivateKey: string,
  encryptedSecret: string
): Promise<string> {
  try {
    const [ivHex, ciphertextHex] = encryptedSecret.split(":")
    if (!ivHex || !ciphertextHex) {
      throw new Error("Invalid encrypted secret format")
    }

    const aesKey = await deriveAesKey(masterPrivateKey)
    const iv = hexToBytes(ivHex)
    const ciphertext = hexToBytes(ciphertextHex)

    const decrypted = await crypto.subtle.decrypt(
      {name: "AES-GCM", iv},
      aesKey,
      ciphertext
    )

    return new TextDecoder().decode(decrypted)
  } catch (error) {
    console.error("[VaultCrypto] decryptSecret failed:", error)
    throw new VaultError(
      "Failed to decrypt secret",
      VAULT_ERROR_CODES.DECRYPTION_FAILED
    )
  }
}

/**
 * 创建新的空保险库数据
 */
export function createEmptyVaultData(): VaultData {
  return {
    version: 1,
    identities: [],
    updatedAt: Date.now(),
  }
}

/**
 * 添加身份到保险库
 */
export function addIdentityToVault(
  vaultData: VaultData,
  identity: VaultIdentity
): VaultData {
  // 检查是否已存在
  if (vaultData.identities.some(i => i.pubkey === identity.pubkey)) {
    throw new VaultError(
      "Identity already exists in vault",
      VAULT_ERROR_CODES.ACCOUNT_EXISTS
    )
  }

  return {
    ...vaultData,
    identities: [...vaultData.identities, identity],
    updatedAt: Date.now(),
  }
}

/**
 * 从保险库移除身份
 */
export function removeIdentityFromVault(
  vaultData: VaultData,
  pubkey: string
): VaultData {
  const identities = vaultData.identities.filter(i => i.pubkey !== pubkey)

  if (identities.length === vaultData.identities.length) {
    throw new VaultError(
      "Identity not found in vault",
      VAULT_ERROR_CODES.ACCOUNT_NOT_FOUND
    )
  }

  return {
    ...vaultData,
    identities,
    updatedAt: Date.now(),
  }
}

/**
 * 更新保险库中的身份
 */
export function updateIdentityInVault(
  vaultData: VaultData,
  pubkey: string,
  updates: Partial<VaultIdentity>
): VaultData {
  const identities = vaultData.identities.map(i =>
    i.pubkey === pubkey ? {...i, ...updates} : i
  )

  if (identities.every(i => i.pubkey !== pubkey)) {
    throw new VaultError(
      "Identity not found in vault",
      VAULT_ERROR_CODES.ACCOUNT_NOT_FOUND
    )
  }

  return {
    ...vaultData,
    identities,
    updatedAt: Date.now(),
  }
}
