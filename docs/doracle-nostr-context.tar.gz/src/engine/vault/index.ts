// index.ts - 无痕账户模块统一导出
// Vault (Incognito Account) module exports

// Types and constants
export {
  VAULT_EVENT_KIND,
  VAULT_EVENT_D_TAG,
  VAULT_ERROR_CODES,
  VaultError,
} from "./types"

export type {
  VaultIdentity,
  VaultData,
  DerivedKey,
  EncryptedVaultContent,
  VaultSessionState,
  VaultOperationResult,
  VaultAuthResult,
  VaultRegisterResult,
  VaultErrorCode,
} from "./types"

// Key derivation
export {deriveMasterKey, verifyKeyPair} from "./keyDerivation"

// Vault crypto
export {
  encryptVault,
  decryptVault,
  encryptSecret,
  decryptSecret,
  createEmptyVaultData,
  addIdentityToVault,
  removeIdentityFromVault,
  updateIdentityInVault,
} from "./vaultCrypto"

// Vault sync
export {VaultSync, vaultSync} from "./vaultSync"

// Session manager
export {VaultSessionManager, vaultSession} from "./sessionManager"

// React hooks
export {
  useVaultUnlocked,
  useVaultIdentities,
  useVaultAccounts,
  useVaultUsername,
  useVaultMasterKey,
} from "./hooks"
