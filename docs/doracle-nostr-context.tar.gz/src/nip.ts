/**
 * src/nip.ts - Nostr 协议统一接口
 *
 * 提供语义化的函数，隐藏 NIP 实现细节。
 * 使用者不需要了解 NIP-19、NIP-44 等概念。
 */

import {
  fromNostrURI,
  GENERIC_REPOST,
  HIGHLIGHT,
  PICTURE_NOTE,
  LONG_FORM,
  NOTE,
  COMMENT,
  REACTION,
  REPOST,
  ZAP_RESPONSE,
  Address,
  RELAYS,
  PROFILE,
  MESSAGING_RELAYS,
  FOLLOWS,
  MUTES,
  getTags,
  getTagValue,
  getTopicTagValues,
  ROOMS,
  FEED,
  NAMED_PEOPLE,
  NAMED_RELAYS,
  NAMED_CURATIONS,
  NAMED_WIKI_AUTHORS,
  NAMED_WIKI_RELAYS,
  NAMED_EMOJIS,
  NAMED_TOPICS,
  NAMED_ARTIFACTS,
  NAMED_COMMUNITIES,
  PINS,
  BOOKMARKS,
  COMMUNITIES,
  CHANNELS,
  TOPICS,
  getPubkey,
} from "@welshman/util"
import {avg, last, nthEq, identity, hexToBytes, bytesToHex} from "@welshman/lib"
import type {TrustedEvent} from "@welshman/util"
import * as _nip19 from "nostr-tools/nip19"
import * as _nip05 from "nostr-tools/nip05"
import * as _nip13 from "nostr-tools/nip13"
import * as _nip49 from "nostr-tools/nip49"
import {generateSecretKey as _generateSecretKey, finalizeEvent as _finalizeEvent} from "nostr-tools/pure"
import {parseJson} from "src/util/misc"

// ============================================
// Section 1: 密钥生成与事件签名
// ============================================

/**
 * 生成新的私钥
 * @returns 十六进制格式的私钥
 */
export const generateSecretKey = (): string => {
  const secretKeyBytes = _generateSecretKey()
  return bytesToHex(secretKeyBytes)
}

/**
 * 签名事件
 * @param template - 事件模板
 * @param secretKey - 十六进制私钥
 * @returns 已签名的事件
 */
export const signEvent = (
  template: {kind: number; created_at: number; tags: string[][]; content: string},
  secretKey: string
) => {
  const secretKeyBytes = hexToBytes(secretKey)
  return _finalizeEvent(template, secretKeyBytes)
}

/**
 * 计算事件的工作量证明
 * @param event - 事件
 * @returns 工作量证明难度
 */
export const getPow = (event: {id: string}): number => {
  return _nip13.getPow(event.id)
}

/**
 * 使用密码加密私钥 (NIP-49)
 * @param secretKey - 十六进制私钥
 * @param password - 加密密码
 * @returns 加密后的字符串
 */
export const encryptSecretKey = (secretKey: string, password: string): string => {
  const secretKeyBytes = hexToBytes(secretKey)
  return _nip49.encrypt(secretKeyBytes, password)
}

/**
 * 解密私钥 (NIP-49)
 * @param encrypted - 加密的私钥字符串
 * @param password - 解密密码
 * @returns 十六进制私钥
 */
export const decryptSecretKey = (encrypted: string, password: string): string => {
  const decrypted = _nip49.decrypt(encrypted, password)
  return bytesToHex(decrypted)
}

// ============================================
// Section 2: 密钥编码/解码
// ============================================

/**
 * 将私钥编码为 nsec 格式
 */
export const encodeNsec = (secretKey: string): string =>
  _nip19.nsecEncode(hexToBytes(secretKey))

/**
 * 解码 nsec 格式的私钥，返回十六进制私钥
 */
export const decodeNsec = (nsec: string): string => {
  const {type, data} = _nip19.decode(nsec)
  if (type !== "nsec") throw new Error(`Invalid nsec`)
  return bytesToHex(data)
}

/**
 * 将公钥编码为 npub 格式
 */
export const encodeNpub = (pubkey: string): string =>
  _nip19.npubEncode(pubkey)

/**
 * 解码 npub 格式的公钥，返回十六进制公钥
 */
export const decodeNpub = (npub: string): string => {
  const {type, data} = _nip19.decode(npub)
  if (type !== "npub") throw new Error(`Invalid npub`)
  return data
}

/**
 * 编码笔记 ID 为 note 格式
 */
export const encodeNote = (id: string): string =>
  _nip19.noteEncode(id)

/**
 * 解码 note 格式，返回事件 ID
 */
export const decodeNote = (note: string): string => {
  const {type, data} = _nip19.decode(note)
  if (type !== "note") throw new Error(`Invalid note`)
  return data
}

/**
 * 编码事件为 nevent 格式
 */
export const encodeNevent = (data: {id: string; relays?: string[]}): string =>
  _nip19.neventEncode(data)

/**
 * 编码公钥和 relay 为 nprofile 格式
 */
export const encodeNprofile = (data: {pubkey: string; relays?: string[]}): string =>
  _nip19.nprofileEncode(data)

/**
 * 验证密钥是否有效（公钥或私钥）
 */
export const isValidKey = (key: string): boolean => {
  try {
    getPubkey(key)
    return true
  } catch {
    return false
  }
}

/**
 * 检查字符串是否为有效的十六进制格式（64字符）
 */
export const isHex = (s: string): boolean =>
  s?.length === 64 && /^[a-f0-9]{64}$/.test(s)

/**
 * 将各种格式的密钥转换为十六进制
 */
export const toHex = (data: string): string | null => {
  if (data.match(/[a-zA-Z0-9]{64}/)) return data

  try {
    let key = _nip19.decode(data).data
    if (key instanceof Uint8Array) {
      key = Buffer.from(key).toString("hex")
    }
    return key as string
  } catch {
    return null
  }
}

// ============================================
// Section 2: 实体解析
// ============================================

/**
 * 解析任何 Nostr 实体（支持 npub, nprofile, note, nevent, naddr, nip05）
 */
export const parseEntity = async (entity: string): Promise<{type: string; data: any} | null> => {
  entity = fromNostrURI(entity)

  // NIP-05 地址
  if (entity.includes("@")) {
    const profile = await _nip05.queryProfile(entity)
    if (profile) {
      return {type: "pubkey", data: profile.pubkey}
    }
  }

  // 地址格式转为 naddr
  if (Address.isAddress(entity)) {
    entity = Address.from(entity).toNaddr()
  }

  if (isHex(entity)) {
    return {type: "pubkey", data: entity}
  }

  try {
    const decoded = _nip19.decode(entity)
    // 转换类型名称为更友好的名称
    const typeMap: Record<string, string> = {
      npub: "pubkey",
      nprofile: "profile",
      note: "event",
      nevent: "event",
      naddr: "address",
      nsec: "secret",
    }
    return {type: typeMap[decoded.type] || decoded.type, data: decoded.data}
  } catch {
    return null
  }
}

/**
 * 同步解析任何 Nostr 实体（不支持 NIP-05）
 */
export const parseEntitySync = (entity: string): {type: string; data: any} | null => {
  entity = fromNostrURI(entity)

  if (Address.isAddress(entity)) {
    entity = Address.from(entity).toNaddr()
  }

  if (isHex(entity)) {
    return {type: "pubkey", data: entity}
  }

  try {
    const decoded = _nip19.decode(entity)
    const typeMap: Record<string, string> = {
      npub: "pubkey",
      nprofile: "profile",
      note: "event",
      nevent: "event",
      naddr: "address",
      nsec: "secret",
    }
    return {type: typeMap[decoded.type] || decoded.type, data: decoded.data}
  } catch {
    return null
  }
}

/**
 * 从各种格式解析公钥
 */
export const parsePubkey = async (entity: string): Promise<string | null> => {
  const result = await parseEntity(entity)
  if (!result) return null

  if (result.type === "pubkey") return result.data
  if (result.type === "profile") return result.data.pubkey
  return null
}

// ============================================
// Section 3: NIP-05 身份验证
// ============================================

/**
 * 查询 NIP-05 身份
 */
export const queryNip05 = async (identifier: string): Promise<{pubkey: string; relays?: string[]} | null> => {
  try {
    const profile = await _nip05.queryProfile(identifier)
    return profile
  } catch {
    return null
  }
}

// ============================================
// Section 4: 事件类型常量
// ============================================

export const REPLY_KINDS = [NOTE, COMMENT]
export const NOTE_KINDS = [...REPLY_KINDS, PICTURE_NOTE, LONG_FORM, HIGHLIGHT]
export const REACTION_KINDS = [REACTION, ZAP_RESPONSE] as number[]
export const REPOST_KINDS = [REPOST, GENERIC_REPOST] as number[]
export const META_KINDS = [PROFILE, FOLLOWS, MUTES, RELAYS, MESSAGING_RELAYS] as number[]
export const HEADERLESS_KINDS = [
  ROOMS, FEED, NAMED_PEOPLE, NAMED_RELAYS, NAMED_CURATIONS,
  NAMED_WIKI_AUTHORS, NAMED_WIKI_RELAYS, NAMED_EMOJIS,
  NAMED_TOPICS, NAMED_ARTIFACTS, NAMED_COMMUNITIES,
  MUTES, PINS, BOOKMARKS, COMMUNITIES, CHANNELS, ROOMS, TOPICS,
]

// 向后兼容的旧命名
export const replyKinds = REPLY_KINDS
export const noteKinds = NOTE_KINDS
export const reactionKinds = REACTION_KINDS
export const repostKinds = REPOST_KINDS
export const metaKinds = META_KINDS
export const headerlessKinds = HEADERLESS_KINDS

export const APP_DATA_KEYS = {
  USER_SETTINGS: "nostr-engine/User/settings/v1",
}

// 向后兼容
export const appDataKeys = APP_DATA_KEYS

// ============================================
// Section 5: 内容分析
// ============================================

const BAD_DOMAINS = ["libfans.com", "matrix.org/_matrix/media/v3/download"]
const WARN_TAGS = new Set(["nsfw", "nude", "nudity", "porn", "ass", "boob", "boobstr", "sex", "sexy", "fuck"])

/**
 * 获取事件的内容警告
 */
export const getContentWarning = (event: TrustedEvent): string | undefined => {
  for (const domain of BAD_DOMAINS) {
    if (event.content.includes(domain)) {
      return "This note includes media from untrusted hosts."
    }
    for (const tag of event.tags) {
      if (tag.some(t => t?.includes(domain))) {
        return "This note includes media from untrusted hosts."
      }
    }
  }

  return (
    getTagValue("content-warning", event.tags) ||
    getTopicTagValues(event.tags).find(t => WARN_TAGS.has(t.toLowerCase()))
  )
}

/**
 * 从事件中提取评级
 */
export const getRating = (event: TrustedEvent): number | undefined =>
  event.kind === 1985
    ? parseJson(last(getTags("l", event.tags).find(nthEq(1, "review/relay")) || []))?.quality
    : parseInt(getTags("rating", event.tags).find(t => t.length === 2)?.[1])

/**
 * 计算事件的平均评级
 */
export const getAvgRating = (events: TrustedEvent[]): number | undefined =>
  avg(events.map(getRating).filter(identity))

// ============================================
// Section 6: 加密存储与通信
// ============================================

// 重导出加密函数（需要在 commands.ts 中使用）
export {nip44EncryptToSelf, setAppData} from "src/engine/commands"

// ============================================
// Section 7: 中继管理
// ============================================

// 重导出中继相关函数
export {
  requestRelayAccess,
  setOutboxPolicy,
  setMessagingPolicy,
  joinRelay,
  leaveRelay,
  broadcastUserData,
  broadcastUserRelays,
} from "src/engine/commands"

// ============================================
// Section 8: 文件上传
// ============================================

export {uploadFile} from "src/engine/commands"

// ============================================
// Section 9: 消息过期管理
// ============================================

export {MessageTTLManager, createMessageTTLManager} from "src/engine/utils/message-ttl"

// ============================================
// Section 10: 向后兼容别名
// ============================================

// 这些函数名保持向后兼容，但建议使用新名称
export const nsecEncode = encodeNsec
export const nsecDecode = decodeNsec
export const isKeyValid = isValidKey
export const parseAnything = parseEntity
export const parseAnythingSync = parseEntitySync
