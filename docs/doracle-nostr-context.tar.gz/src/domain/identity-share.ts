/**
 * Identity sharing utilities for Doracle
 *
 * Provides encoding/decoding of identity information for sharing via:
 * - doracle:// URL scheme
 * - JSON file export/import
 */

import { decodeNpub, encodeNpub } from "src/nip"

export const IDENTITY_SHARE_VERSION = 1
export const DORACLE_IDENTITY_SCHEME = "doracle://identity"

export interface IdentityShare {
  v: number // 版本号
  npub: string // 公钥（必需）
  name?: string // 昵称
  relay?: string // 推荐中继
  nip05?: string // NIP-05 标识
  avatar?: string // 头像 URL
}

/**
 * Encode identity to doracle:// URL format
 * Example: doracle://identity?v=1&npub=npub1xxx&name=Test&relay=wss://relay.example.com
 */
export function encodeIdentityUrl(identity: IdentityShare): string {
  const params = new URLSearchParams()

  params.set("v", String(identity.v))
  params.set("npub", identity.npub)

  if (identity.name) params.set("name", identity.name)
  if (identity.relay) params.set("relay", identity.relay)
  if (identity.nip05) params.set("nip05", identity.nip05)
  if (identity.avatar) params.set("avatar", identity.avatar)

  return `${DORACLE_IDENTITY_SCHEME}?${params.toString()}`
}

/**
 * Decode doracle:// URL or JSON string to IdentityShare
 * Supports:
 * - doracle://identity?... URL format
 * - JSON string with IdentityShare structure
 */
export function decodeIdentity(input: string): IdentityShare | null {
  const trimmed = input.trim()

  // Try doracle:// URL format
  if (trimmed.startsWith("doracle://identity")) {
    try {
      const url = new URL(trimmed)
      const params = url.searchParams

      const npub = params.get("npub")
      if (!npub) return null

      // Validate npub
      try {
        decodeNpub(npub)
      } catch {
        return null
      }

      return {
        v: parseInt(params.get("v") || "1", 10),
        npub,
        name: params.get("name") || undefined,
        relay: params.get("relay") || undefined,
        nip05: params.get("nip05") || undefined,
        avatar: params.get("avatar") || undefined,
      }
    } catch {
      return null
    }
  }

  // Try JSON format
  try {
    const json = JSON.parse(trimmed)
    if (json && typeof json === "object" && json.npub) {
      // Validate npub
      try {
        decodeNpub(json.npub)
      } catch {
        return null
      }
      return {
        v: json.v || IDENTITY_SHARE_VERSION,
        npub: json.npub,
        name: json.name || undefined,
        relay: json.relay || undefined,
        nip05: json.nip05 || undefined,
        avatar: json.avatar || undefined,
      }
    }
  } catch {
    // Not JSON
  }

  return null
}

/**
 * Create IdentityShare from pubkey and optional profile data
 */
export function createIdentityShare(pubkey: string, profile?: any): IdentityShare {
  const identity: IdentityShare = {
    v: IDENTITY_SHARE_VERSION,
    npub: encodeNpub(pubkey),
  }

  if (profile) {
    if (profile.name || profile.display_name) {
      identity.name = profile.display_name || profile.name
    }
    if (profile.nip05) {
      identity.nip05 = profile.nip05
    }
    if (profile.picture) {
      identity.avatar = profile.picture
    }
  }

  return identity
}

/**
 * Download identity as JSON file
 */
export function exportIdentityFile(identity: IdentityShare): void {
  const json = JSON.stringify(identity, null, 2)
  const blob = new Blob([json], { type: "application/json" })
  const url = URL.createObjectURL(blob)

  // Use name for filename if available, otherwise use npub prefix
  const filename = identity.name
    ? `doracle-identity-${identity.name.replace(/[^a-zA-Z0-9]/g, "_")}.json`
    : `doracle-identity-${identity.npub.slice(0, 12)}.json`

  const link = document.createElement("a")
  link.href = url
  link.download = filename
  link.click()

  // Cleanup
  URL.revokeObjectURL(url)
}

/**
 * Parse file content as IdentityShare
 */
export function parseIdentityFile(content: string): IdentityShare | null {
  return decodeIdentity(content)
}
